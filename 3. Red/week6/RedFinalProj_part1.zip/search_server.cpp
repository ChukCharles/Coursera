#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <numeric>
#include <iterator>
#include <sstream>
#include <iostream>
#include <chrono>

size_t MAX_DOCUMENT_COUNT = 50'000;


vector<string> SplitIntoWords(string line) {
  istringstream words_input(move(line));
  return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
  UpdateDocumentBase(document_input);
}

SearchServer::~SearchServer() {
    //cout << "durations:\n"
    //    << "split: " << durations.split << "\n"
    //    << "map construction: " << durations.map_ctor << "\n"
    //    << "vector ctor: " << durations.vector_ctor << "\n"
    //    << "sort: " << durations.sort << "\n"
    //    << "vector clear: " << durations.vector_clear << endl;
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
  InvertedIndex new_index;

  for (string current_document; getline(document_input, current_document); ) {
    new_index.Add(move(current_document));
  }

  index = move(new_index);
}

void SearchServer::AddQueriesStream(
  istream& query_input, ostream& search_results_output
) {
    //chrono::steady_clock::time_point vc_start = chrono::steady_clock::now();
    vector<pair<size_t, size_t>> docid_count(index.GetDocsSize());
    fill(docid_count.begin(), docid_count.end(), make_pair(0, 0));
    //chrono::steady_clock::time_point vc_stop = chrono::steady_clock::now();
    //cout << "create vector: " << duration_cast<chrono::milliseconds>(vc_stop - vc_start).count() << endl;

    for (string current_query; getline(query_input, current_query); ) {

        chrono::steady_clock::time_point start = chrono::steady_clock::now();
        vector<string> words = SplitIntoWords(current_query);
        chrono::steady_clock::time_point split = chrono::steady_clock::now();
        durations.split += duration_cast<chrono::milliseconds>(split-start).count();

        //--------------------------------------
        //map creation
        for (string& word : words) {
            for (const pair<size_t, size_t>& docid : index.Lookup(move(word))) {
                if (docid_count[docid.first].first == 0) docid_count[docid.first].first = docid.first;
                docid_count[docid.first].second += docid.second;
            }
        }

        chrono::steady_clock::time_point map = chrono::steady_clock::now();
        durations.map_ctor += duration_cast<chrono::milliseconds>(map - split).count();
        
        //--------------------------------------
        // sorting
        partial_sort(
            begin(docid_count),
            Head(docid_count, 5).end(),
            end(docid_count),
            [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
                //int64_t lhs_docid = lhs.first;
                //auto lhs_hit_count = lhs.second;
                //int64_t rhs_docid = rhs.first;
                //auto rhs_hit_count = rhs.second;
                //return make_pair(lhs_hit_count, -lhs_docid) > make_pair(rhs_hit_count, -rhs_docid);
                //return make_pair(lhs.second, -1 * int64_t(lhs.first)) > make_pair(rhs.second, -1 * int64_t(rhs.first));
                return make_pair(lhs.second, rhs.first) > make_pair(rhs.second, lhs.first);
            }
        );
        chrono::steady_clock::time_point sort = chrono::steady_clock::now();
        durations.sort += duration_cast<chrono::milliseconds>(sort - map).count();

        //--------------------------------------
        // output
        search_results_output << current_query << ':';
        for (auto& [docid, hitcount]  : Head(docid_count, 5)) {
            if (hitcount == 0) break;
            search_results_output << " {"
            << "docid: " << docid << ", "
            << "hitcount: " << hitcount << '}';
        }
        search_results_output << endl;

        //--------------------------------------
        // clear vector
        chrono::steady_clock::time_point out = chrono::steady_clock::now();
        fill(docid_count.begin(), docid_count.end(), make_pair( 0, 0 ));

        chrono::steady_clock::time_point vector_clear = chrono::steady_clock::now();
        durations.vector_clear += duration_cast<chrono::milliseconds>(vector_clear - out).count();
    }
}

void InvertedIndex::Add(string document) {
    const size_t docid = docs.size();
    map<string, size_t> word_count;
    for (const auto& word : SplitIntoWords(move(document))) {
        word_count[word]++;
    }

    for (auto& pair : word_count) {
        index[pair.first].push_back({ docid, pair.second });
    }
    docs.push_back("");
}

const vector<pair<size_t, size_t>>& InvertedIndex::Lookup(const string& word) const {
    vector<size_t> result;
    if (auto it = index.find(word); it != index.end()) {
        return it->second;
    } else {
        return empty;
    }
}
