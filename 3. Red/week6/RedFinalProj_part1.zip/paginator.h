#include <numeric>
#include <vector>
#include <iterator>
#include <algorithm>
#include <utility>

#include "iterator_range.h"

using namespace std;

template <typename Iterator>
class Paginator {
public:
    Paginator(Iterator begin, Iterator end, size_t page_size) {
        Iterator page_start = begin;
        while (page_start != end) {
            Iterator page_end = page_start;
            for (int i = 0; i < page_size && page_end != end; i++ ) advance(page_end, 1);
            pages.push_back({ page_start, page_end });
            page_start = page_end;
        }
    }

    size_t size() const { return pages.size(); }

    auto begin() { return pages.begin(); }
    auto end() { return pages.end(); }


private:
    vector<IteratorRange<Iterator>> pages;
};

template <typename C>
auto Paginate(C& c, size_t page_size) {
    return Paginator(c.begin(), c.end(), page_size);
}