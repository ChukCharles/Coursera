#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <numeric>
#include <iterator>
#include <sstream>
#include <iostream>
#include <chrono>
#include <exception>

size_t MAX_DOCUMENT_COUNT = 50'000;


vector<string> SplitIntoWords(string line) {
    istringstream words_input(move(line));
    return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
    UpdateDocumentBaseSingleThread(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
    futures.push_back(
        async(&SearchServer::UpdateDocumentBaseSingleThread, this, ref(document_input))
    );
}
void SearchServer::UpdateDocumentBaseSingleThread(istream& document_input) {
    InvertedIndex new_index;

    for (string current_document; getline(document_input, current_document); ) {
        new_index.Add(move(current_document));
    }

    //lock_guard g(index_mutex);
    swap(new_index, index.GetAccess().ref_to_value);
}


void SearchServer::AddQueriesStream(
  istream& query_input, ostream& search_results_output
) {
    futures.push_back(
        async(&SearchServer::AddQueriesStreamSingleThread, this, ref(query_input), ref(search_results_output)));

}

void SearchServer::AddQueriesStreamSingleThread(
    istream& query_input, ostream& search_results_output
) {
    vector<pair<size_t, size_t>> docid_count(index.GetAccess().ref_to_value.GetDocsSize());

    for (string current_query; getline(query_input, current_query); ) {
        fill(docid_count.begin(), docid_count.end(), make_pair(0, 0));
        vector<string> words = SplitIntoWords(current_query);

        //--------------------------------------
        //map creation
        for (string& word : words) {
            for (const pair<size_t, size_t>& docid : index.GetAccess().ref_to_value.Lookup(word)) {
                if (docid_count[docid.first].first == 0) docid_count[docid.first].first = docid.first;
                docid_count[docid.first].second += docid.second;
            }
        }

        //--------------------------------------
        // sorting
        partial_sort(
            begin(docid_count),
            Head(docid_count, 5).end(),
            end(docid_count),
            [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
                return make_pair(lhs.second, rhs.first) > make_pair(rhs.second, lhs.first);
            }
        );

        //--------------------------------------
        // output
        search_results_output << current_query << ':';
        for (auto& [docid, hitcount] : Head(docid_count, 5)) {
            if (hitcount == 0) break;
            search_results_output << " {"
                << "docid: " << docid << ", "
                << "hitcount: " << hitcount << '}';
        }
        search_results_output << endl;
    }
}


void InvertedIndex::Add(string document) {
    size_t docid = docs.size();
    docs.push_back("");

    map<string, size_t> word_count;
    for (const auto& word : SplitIntoWords(move(document))) {
        word_count[word]++;
    }

    for (auto& pair : word_count) {
        index[pair.first].push_back({ docid, pair.second });
    }
}

const vector<pair<size_t, size_t>>& InvertedIndex::Lookup(const string& word) const {
    vector<size_t> result;
    if (auto it = index.find(word); it != index.end()) {
        return it->second;
    } else {
        return empty;
    }
}
